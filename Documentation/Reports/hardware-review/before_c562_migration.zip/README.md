# STM32 温度 / 流量显示板 · A0

本版选用 **STM32C531CBT6**（LQFP48，128 KB Flash、64 KB SRAM，Cortex-M33，最高 144 MHz）。它的 ADC、定时器、I²C 和原生 USB 足够完成本项目；48 脚封装方便焊接、调试，也保留了扩展引脚。

按你的要求：外围电路独立分页，页内相关器件用导线连接；全部电阻、电容使用 **0603 英制 / 1608 公制**。旧 `code/` 未作为设计依据。MCU 最小系统由你绘制，已提供专用符号和引脚表。

## 打开与查看

用 KiCad 10 打开 [ssd.kicad_pro](ssd.kicad_pro)，再打开原理图或 PCB。项目库均通过 `${KIPRJMOD}` 引用，无需额外安装元件库。

主导航页用带箭头的功能连接线展示四个模块的供电、烧录、调试及数据关系；实际电气连接仍由子页中的同名网络关联。五页说明、接口线色、PCB 暂放注释和屏幕对位图均使用中文；型号、标准引脚名及网络标识保留原写法。

| 文件 | 内容 |
| --- | --- |
| [ssd.kicad_sch](ssd.kicad_sch) | 总页、四个子页入口 |
| [usb_power.kicad_sch](usb_power.kicad_sch) | USB-C、ESD、5V→3.3V、BOOT / RESET、SWD |
| [display.kicad_sch](display.kicad_sch) | HT16K33、I²C 电平转换、屏幕与限流电阻 |
| [sensors.kicad_sch](sensors.kicad_sch) | NTC 分压 / 滤波、霍尔脉冲整形、用户按键 |
| [mcu_minimum.kicad_sch](mcu_minimum.kicad_sch) | 留给你绘制的最小系统页，含接线说明 |
| [原理图 PDF](review/ssd_schematic.pdf) | 五页完整预览 |
| [ssd.kicad_pcb](ssd.kicad_pcb) | 50 个外围封装及网络，按功能分组暂放 |
| [封装预览](review/footprints_staged.pdf) | 封装暂放图，非最终布局 |
| [BOM.csv](docs/BOM.csv) | 外围器件采购规格与封装 |
| [设计说明](docs/DESIGN_NOTES.md) | 接口、显示映射、机械假设及验证范围 |

PCB 尚未加入 MCU、板框或布线。这里交付的是原理图和配套封装，不是生产文件。

## MCU 与 USB 烧录

**STM32C531 支持出厂 ROM Bootloader 的 USB Device DFU。** 依据为 ST DS15125 Rev3 §3.5，以及 AN2606 Rev70 第 10 章、表 20（印刷页 79–81）。USB 使用 PA11 / PA12，DFU 使用 HSI / 3 的 48 MHz 时钟和 CRS，不要求外部 HSE 晶振。内部包含 USB D+ 上拉及串联匹配电阻，本电路没有额外的 1.5 kΩ 上拉或 22 Ω 串联电阻，也不需要 USB 转串口芯片。

USB-C 作为 5V 受电端；CC1、CC2 分别接 5.1 kΩ 下拉。使用具有数据线的 USB 线连接电脑，同一个接口可供电和 DFU 烧录。

1. 首次调试保留 SWD，用 STM32CubeProgrammer 检查选项字节。要使用 BOOT 按键进入 ROM，应使 **BOOT_SEL = 1**，由外部 BOOT0 引脚选择启动模式。
2. 按住 BOOT，按下并释放 RESET，再释放 BOOT。
3. 在 STM32CubeProgrammer 选择 USB，连接 DFU 设备，下载并校验程序。
4. BOOT 释放后再次复位，从用户 Flash 启动。

空片也可在 AN2606 Pattern19 对应选项配置下通过空 Flash 检测进入 ROM；不能据此假定所有选项字节状态都允许按键进入 DFU。首次调试不要关闭 SWD 或锁定启动选项。

## 你绘制最小系统时的连接表

从项目库放置 `SSD:STM32C531CBT6`。其封装已指定为 LQFP-48，7 × 7 mm，0.5 mm 引脚间距。以下均为 **C531 的 LQFP48 实际脚号**。

| 外围网络名 | MCU 引脚 | 封装脚号 | 用途 |
| --- | --- | --- | --- |
| NTC_ADC | PA0 | 10 | ADC1_IN0 |
| FLOW_PULSE | PA1 | 11 | TIM2_CH2 / AF1，或 EXTI |
| USB_DM | PA11 | 32 | USB D− |
| USB_DP | PA12 | 33 | USB D+ |
| I2C_SCL | PB6 | 42 | I2C1_SCL / AF4 |
| I2C_SDA | PB7 | 43 | I2C1_SDA / AF4 |
| USER_KEY | PC13 | 2 | 低电平按下 |
| SWDIO | PA13 | 34 | 调试数据 |
| SWCLK | PA14 | 37 | 调试时钟 |
| MCU_BOOT0 | PH2-BOOT0 | 44 | 启动模式；不是 F103 的 BOOT0 脚号 |
| MCU_NRST | NRST | 7 | 复位 |

供电连接参照 DS15125 Rev3 第 48 页 Figure 13：

- VDD：24 / 36 / 48 → +3V3；VSS：23 / 35 / 47 → GND。
- 每个 VDD 就近放 100 nF，MCU 附近另放 4.7 µF；均采用 0603。
- VREF+：9 → 3.3V 参考电源，就近放 100 nF 到 VREF−；VREF−：8 → GND。模拟参考与 ADC 地回路应避开 LED 扫描电流。
- **VCAP：22 只接 2.2 µF 陶瓷电容到 GND**，不接 3.3V、不对外供电。电容额定电压 ≥10V，ESR 在 3 MHz 时 <20 mΩ；挑选满足该条件的 0603，并核对厂商阻抗曲线。
- BOOT / RESET 的电阻、电容、按键已在 USB 页，不需重复放置。SWD 接口的 3.3V 为目标板电压参考，不要让调试器与板上 LDO 同时向该网供电。

## 已做的检查

- KiCad 10.0.6 可解析并导出全部五页；ERC **0 个错误、5 个警告**。警告对应尚未连接 MCU 的 USB_DM、USB_DP、SWDIO、SWCLK、FLOW_PULSE，未排除这些警告。
- [网络核对](review/netlist_checks.json)：50 个器件、160 个已连接引脚、50 个独立网络，逐网检查无误；23 个电阻、11 个电容全部为 0603。
- [PCB 核对](review/pcb_checks.json)：50 个封装、183 个焊盘，已检查焊盘网络和原理图 UUID 对应关系，暂放的封装几何没有相互重叠。
- [PCB DRC](review/drc_unrouted.json) 保留未布线和未画板框的提示。USB-C 原厂推荐封装的非镀孔到相邻铜间距约 0.1944 mm，小于当前项目 0.25 mm 规则，仍有 4 条间距错误；未通过修改孔位或放宽规则掩盖。后续制板须确定厂家能力，必要时更换连接器及封装。
- 显示屏封装、接插件配套和实际亮度仍需实物验证，详见设计说明。没有声称已完成整板制造检查或实测。

原始空工程备份在 [original_empty_project.zip](review/original_empty_project.zip)。`tools/check_netlist.py` 只读取导出的网络表和本版连接清单，不会改写原理图；添加 MCU 后应同步更新检查基准。
