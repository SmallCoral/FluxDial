# A0 设计依据与待验证项

## 原始器件文档

项目根目录 `word/` 中实际为三份 PDF：

| 文档 | 本版采用的参数 |
| --- | --- |
| `180长规格书(1).pdf` | NTC 50 kΩ ±1% @25℃，B25/50 =3950 K ±1%，−30～105℃；温度换算优先用厂商 R-T 表 |
| `BTL-004A涡轮霍尔规格书(1).pdf` | 5V；红线电源、黄线脉冲、白线地；F=11Q，660 脉冲/L；高电平 ≥4.7V |
| `20250303远帆5858-1DRWB-10(1).pdf` | 58mm 共阴屏，6 个公共端、10 条段线；双列排距 35.08mm、同列针距 2.54mm |

流量规格书的量程在不同位置分别写了 2–12 L/min 和 1–25 L/min，本版不擅自消除该矛盾；测量有效范围需要向供应商确认并实测标定。F=11Q 得出 Q=F/11，累计体积 L=N/660，仅作为初始换算。

## 温度与流量接口

J301：1=3.3V，2=NTC_RAW；外部 NTC 跨接两脚。49.9 kΩ / 0.1% 电阻接信号到地，1 kΩ 与 100 nF 构成 ADC 滤波。公式为 `Rntc = 49.9k × (Vref / Vadc − 1)`；正常使用同一 3.3V 供电和 ADC 参考时为比率测量。开路趋近 0V、短路趋近满量程，固件需判故障，避免直接除以零。

BAV199 用于低漏电钳位：1=A1 接 GND、2=K2 接 3.3V、3=K1/A2 接 ADC。保护能力仍取决于串联电阻、外部异常电压和 MCU 注入电流限制，不能把它当作任意电压输入端。ADC 使用较长采样时间；上电及改变采样配置后留出滤波稳定时间。NTC 固有误差、参考电阻误差和实际安装热耦合需要校准。

J302：1=红线 5V，2=黄线脉冲，3=白线 GND。10 kΩ 上拉兼容开漏输出，4.7 kΩ / 1 nF 抑制窄毛刺。SN74LVC1G17DCKR 用 3.3V 供电，输入允许 5.5V，输出 3.3V 施密特整形脉冲到 PA1。不要把 5V 原始脉冲绕过缓冲器接入 MCU。

两只连接器暂用 JST XH、2.50mm、立式直插。供应商文档仅称 XHB，不足以唯一确定塑壳、针序和配套端子。请核对实物；XH 的 2.50mm 不等于 2.54mm。

## 显示驱动

U201 是 **Holtek HT16K33，28 引脚 SOP**，5V 供电。SOP 外形已核对官方 Rev1.10 第 40 页：1.27mm 脚距、17.70–18.11mm 长、最大 7.62mm 本体宽，采用 KiCad `SOIC-28W_7.5x17.9mm_P1.27mm` 焊盘。不要直接采购 20/24 脚版本或未经核对的兼容芯片。

PB6/PB7 的 3.3V I²C 经两只 BSS138 转换到 5V，低压侧为 Source、高压侧为 Drain、Gate 接 3.3V。两侧各有 4.7 kΩ 上拉，初次调试用 100 kHz。

| HT16K33 | 驱动脚号 | 串联电阻 | 屏幕段线 | 屏幕脚号 |
| --- | --- | --- | --- | --- |
| ROW0 | 25 | R201 | A | 15 |
| ROW1 | 24 | R202 | B | 14 |
| ROW2 | 23 | R203 | C | 13 |
| ROW3 | 22 | R204 | D | 12 |
| ROW4 | 21 | R205 | E | 11 |
| ROW5 | 20 | R206 | F | 10 |
| ROW6 | 19 | R207 | G | 9 |
| ROW7 | 18 | R208 | H | 8 |
| ROW8 | 17 | R209 | I | 7 |
| ROW9 | 16 | R210 | J | 16 |

COM0～COM5（芯片 2～7 脚）直接接屏幕 COM1～COM6（屏幕 1～6 脚）。COM6/7、ROW10～15 留空。

无地址选择二极管时使用 7 位 I²C 地址 **0x70**。建议初始化：系统振荡器开启 `0x21` → 显示关闭 `0x80` → 清零 16 字节显示 RAM → 低亮度 `0xE0` → 显示开启 / 无闪烁 `0x81`。RAM 每个 COM 占两个字节；第 i 个 COM 的地址为 2i，ROW0～7 对应低字节，ROW8～15 对应高字节。只使用前六个 COM 的低十位，其余保持零。

R201～R210 初值 330Ω，以限制未知实物状态下的峰值电流。HT16K33 为扫描驱动，白 / 红 / 蓝段的正向压降不同，实际电流还受驱动压降影响；不能把扫描平均电流当作规格书的直流建议电流。必须用样屏检查峰值电流、平均亮度及颜色平衡，再决定是否调整阻值和 PWM 亮度。不要套用旧固件的扫描表。

## 屏幕封装与布局

自建 `SSD:ALS5858_1DRWB_10`：外径 58mm，两排各 8 脚，排距 35.08mm，针距 2.54mm，同排首尾跨度 17.78mm。按供应商显示正面图，1 脚位于左上，左排 1→8 向下，右排 9→16 向上；PCB 顶面用于安装显示屏。未臆造安装孔。

**1.0mm 钻孔、2.0mm 焊盘属于暂定值**：供应商图写了针径公差，但未给出针径标称值。打样前测针径，确认镀后孔余量，并用 [1:1 对位图](../review/display_footprint_1to1.pdf) 100% 打印检查尺寸和方向。打印时关闭“适合页面”，先量图中的 20mm 标尺。封装的 58mm 轮廓不代表 PCB 板框。

当前 PCB 仅为封装暂放。后续布局应将 ESD 紧靠 USB-C，D+/D− 在接口至 MCU 之间连续成对走线，按实际板厚、铜厚、参考平面计算 90Ω 差分阻抗。传感器模拟地回路避免与 LED COM 回流共用狭窄路径，LDO / 缓冲器 / 驱动器去耦靠近各自电源脚。LED 屏下方元件高度和可用空间也需实物核对。

## USB 电源与器件采购

F101 使用 1206、0.5A 保持电流的自恢复保险丝，可选 Littelfuse 1206L050YR 或核对参数后的同封装替代品。保险丝不属于本次“电阻电容统一 0603”的范围。AP2112K-3.3TRG1 提供 3.3V，C103 必须在直流偏压、容差和温度范围内仍满足其输出电容要求；不能只看 0603 标称容量。普通电容选 X5R / X7R、≥10V，滤波 1nF 可用 C0G。

直接接 5V 的板上电容合计标称约 4.4µF，减少插入时充电负担。3.3V 电容、用户补充的 MCU 去耦、传感器内部电容也会影响插入瞬态，接上最小系统后仍需测量 USB 涌入电流。

按 5V / 500mA 电源规划整机，实际平均与峰值电流待测；0.5A 保险丝不会自动完成 USB 电流协商。连接普通电脑端口时，应用固件需完成 USB 枚举并申报所需电流，在获准前控制总负载，初次点屏从低亮度开始。没有 PD 升压功能，不接受把 9V / 12V 注入 VBUS。

SW101、SW102、SW301 使用 TL3342 系列对应贴片封装；采购前核对按键本体和触点排列。SWD 接口为 2.54mm 1×5 排针，针序详见原理图，不是 ST 标准 10 针接口。

## 参考资料与库来源

- [STM32C53xxx DS15125 Rev3](reference/STM32C53xxx_DS15125_Rev3.pdf)：§3.5 Bootloader、引脚表、p48 供电与 VCAP、USB 电气特性。来源：ST 官方 `https://www.st.com/resource/en/datasheet/stm32c531cc.pdf`。
- [AN2606 Rev70](reference/AN2606_Rev70.pdf)：Pattern19、第 10 章 C531/532/542 Bootloader，表 20 USB 引脚与时钟。来源：`https://www.st.com/resource/en/application_note/an2606-stm32-microcontroller-system-memory-boot-mode-stmicroelectronics.pdf`。
- [ST LQFP48 引脚 JSON](reference/STM32C531_LQFP48_pinout.json)：来自 STMicroelectronics/stm32c5xx-dfp 的 `Descriptors/pinout/STM32C531C(B-C)Tx_pinout.json`，并与数据手册核对。
- [HT16K33 Rev1.10](reference/HT16K33_Rev110.pdf)：Holtek RAM Mapping 16×8 LED Controller Driver，2011-05-16，28-SOP 引脚、RAM 和封装。
- [AP2112](reference/AP2112.pdf)：Diodes Incorporated，`https://www.diodes.com/assets/Datasheets/AP2112.pdf`。
- [SN74LVC1G17](reference/SN74LVC1G17.pdf)：Texas Instruments，`https://www.ti.com/lit/ds/symlink/sn74lvc1g17.pdf`。
- [BAV199 文本摘录](reference/BAV199_reference.txt)：Nexperia，2023-04-01 数据手册；原文 `https://assets.nexperia.com/documents/data-sheet/BAV199.pdf`。
- 标准符号、标准焊盘来自 KiCad 10.0.6 分发库。本项目复制到 `libraries/` 并移除外部 3D 模型依赖；BAV199 图形与脚号已按 Nexperia 资料修正，C531 / HT16K33 / 屏幕符号及屏幕封装为本版自建。标准库采用 KiCad Libraries 的 CC BY-SA 4.0 及设计作品例外，见 `https://www.kicad.org/libraries/license/`。来源与本地名称映射保存在 `review/design_manifest.json`。
